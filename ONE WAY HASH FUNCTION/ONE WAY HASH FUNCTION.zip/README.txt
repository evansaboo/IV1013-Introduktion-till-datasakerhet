COMPILATION: $ javac Brute_Force.java
EXECUTION: $ java Brute_Force "Word or Sentence"
Example: $ java Brute_Force IV1013
Example 2: $ java Brute_Force "Security is fun"

Output:
Digest for the message "IV1013", using SHA-256 is:
cd9749f49c830c8138236985681289a7b455fe756f4047f2ad100074b996f907

Collision Detected! Only 24 bits of the given hash could be matched..
Digest for the message "F_R", using SHA-256 is:
cd97497c512bd44bdf8d55810a0c246320c39fb66de02b7202530f14bc55fabd
It took 4659539 tries until a collision was found.


